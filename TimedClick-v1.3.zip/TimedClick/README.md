# TimedClick v1.3

Windows 图形界面定时单次点击工具，可将一次鼠标左键点击安排在指定的北京时间、新加坡时间或 UTC 时间。

## 使用

1. 在 Windows 10 或 11 上解压或克隆本仓库。
2. 双击 `Start.cmd`。
3. 在付款页面填好信息，点击工具中的“3 秒后记录位置”，并在倒计时内将鼠标移到付款按钮中央。
4. 设置日期、秒和 `000–999` 毫秒，点击“启动定时点击”，再切回付款页。

F9 或 Esc 可取消。工具只发送一次鼠标点击；付款、验证码、密码及网页结果由用户自行处理。

## 文件

- `Start.cmd`：启动入口。
- `TimedClick.ps1`：PowerShell 加载器。
- `TimedClick.cs`：完整可检查、可修改的 C# 源码。
- `使用说明.txt`：中文使用说明。
- `TimedClick-v1.3.zip`：便于复制到另一台 Windows 电脑的完整压缩包。

## 自检

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File .\TimedClick.ps1 -SelfTest
```

自检不产生鼠标点击。实际触发时间受 Windows 调度、系统时钟及网页网络响应影响。
